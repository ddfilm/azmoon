<?php
// امنیت و اعتبارسنجی
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$questionsFile = 'questions.json';
$questions = file_exists($questionsFile) ? json_decode(file_get_contents($questionsFile), true) : [];

// افزودن سوال جدید
if (isset($_POST['add_question'])) {
    // اعتبارسنجی پاسخ صحیح
    $correctAnswer = (int)$_POST['correct_answer'];
    $optionsCount = count($_POST['options']);
    
    // اگر پاسخ صحیح خارج از محدوده گزینه‌ها باشد، اولین گزینه را انتخاب می‌کند
    if ($correctAnswer < 0 || $correctAnswer >= $optionsCount) {
        $correctAnswer = 0;
    }

    $newQuestion = [
        'question' => $_POST['question'],
        'options' => $_POST['options'],
        'answer' => $correctAnswer, // پاسخ صحیح از فرم دریافت می‌شود
        'category' => $_POST['category'],
        'image' => ''
    ];

    // آپلود تصویر
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../pic/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $newQuestion['image'] = 'pic/' . $fileName;
        }
    }

    $questions[] = $newQuestion;
    file_put_contents($questionsFile, json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    header('Location: index.php?success=1');
    exit;
}

// حذف سوال
if (isset($_POST['delete_question'])) {
    $index = (int)$_POST['delete_index'];
    if (isset($questions[$index])) {
        // حذف تصویر مرتبط اگر وجود دارد
        if (!empty($questions[$index]['image'])) {
            $imagePath = '../' . $questions[$index]['image'];
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
        }
        
        array_splice($questions, $index, 1);
        file_put_contents($questionsFile, json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    header('Location: index.php');
    exit;
}